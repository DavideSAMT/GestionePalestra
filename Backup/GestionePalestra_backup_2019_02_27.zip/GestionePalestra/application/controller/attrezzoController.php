<?php

class AttrezzoController {

    function index($attrezzoID = null) {
        // Dati
        require_once 'application/models/attrezzo.php';
        $attrezzo = new Attrezzo();
        $attrezzo->setID($attrezzoID);
        $desc = $attrezzo->getDescrizione();
        $nome = $attrezzo->getNome();
        $link = $attrezzo->getLink();
        // View
        require 'application/views/_template/header.php';
        require 'application/views/attrezzo/index.php';
        require 'application/views/_template/footer.php';
    }
    
}