<?php

class ClienteController {

    public function index() {
        // Controllo che la sessione sia settata
        // altrimenti faccio ritornare l'utente alla home
        if (!isset($_SESSION['mail'])) header("location: " . URL);
        // Se la mail che ha fatto login é dell'amministratore 
        // verrà aperta la pagina del responsabile
        if (!strcmp($_SESSION['mail'], ADMIN)) header("location: " . URL."clienteController/responsabile");
        require_once 'application/models/cliente.php';
        // Istanzio un oggetto Cliente in base alla sua mail
        $cliente = new Cliente($_SESSION['mail']);
        // Prendo il suo nome completo
        $fullName = $cliente->getFullName();
        // Prendo la sua altezza
        $altezza = $cliente->getAltezza();
        // Formatto le cifre della massa
        $altezza = number_format($altezza,2);
        // Prendo la sua massa
        $massa = $cliente->getMassa();
        // Prendo il suo BMI
        $BMI = $cliente->getBMI();
        // Formatto le cifre del BMI
        $BMI = number_format($BMI,2);
        // View
        require 'application/views/_template/header.php';
        require 'application/views/cliente/index.php';
        require 'application/views/_template/footer.php';
    }
    
    public function mieSchede() {
        // Controllo che la sessione sia settata
        // altrimenti faccio ritornare l'utente alla home
        if (!isset($_SESSION['mail'])) header("location: " . URL);
        require_once 'application/models/cliente.php';
        // Istanzio un oggetto Cliente in base alla sua mail
        $cliente = new Cliente($_SESSION['mail']);
        // Ricavo l'id dal cliente
        $idCliente = $cliente->getId();
        require_once 'application/models/scheda.php';
        // Istanzio un oggetto Scheda 
        $scheda = new Scheda();
        // Setto l'id del cliente nell oggetto scheda
        $scheda->setIdCliente($idCliente);
        // Prendo tutte le schede di quel cliente
        $schedeCliente = $scheda->getFromCliente();
        // View
        require 'application/views/_template/header.php';
        require 'application/views/cliente/storicoSchede.php';
        require 'application/views/_template/footer.php';
    }
    
    public function responsabile() {
        // Se la mail non é del responsabile o se la sessione non é stata registrata
        // l'utente viene reindirizzato alla home
        if (!isset($_SESSION['mail'])) header("location: " . URL);
        if (strcmp($_SESSION['mail'], ADMIN)) header("location: " . URL);
        // View
        require 'application/views/_template/header.php';
        require 'application/views/responsabile/index.php';
        require 'application/views/_template/footer.php';
    }

}