<?php

class Home {

    public function index() {
        // Dati
        require_once 'application/models/attrezzo.php';
        $att = new Attrezzo();
        $data = $att->getAll();
        // View
        require 'application/views/_template/header.php';
        require 'application/views/home/index.php';
        require 'application/views/_template/footer.php';
    }

}
