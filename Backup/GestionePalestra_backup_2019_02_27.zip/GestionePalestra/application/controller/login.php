<?php

class Login {

    public function index() {
        require 'application/views/login/index.php';
    }

    public function signUp() {
        require_once 'application/models/formCheck.php';
        require_once 'application/models/cliente.php';
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            // Controllo che i campi non siano vuoti
            if (!FormCheck::areSet($_POST)) {
                // Segnalo all'utente l'errore
                FormCheck::phpAlert('Devono essere riempiti tutti i campi del form.');
                // Ritorno al login
                $this->index();
                return;
            }
            // Controllo se la mail é già stata registrata
            else if (Cliente::existsMail($_POST['mail'])){
                // Segnalo all'utente l'errore
                FormCheck::phpAlert('La mail è già stata utilizzata.');
                // Ritorno al login
                $this->index();
                return;
            }
            // Controllo che le due password non siano differenti
            else if (strcmp($_POST['password'], $_POST['confirm-password'])) {
                // Segnalo all'utente l'errore
                FormCheck::phpAlert('Le password non sono uguali.');
                // Ritorno al login
                $this->index();
                return;
            }
            // Calcolo il BMI
            $bmi = Cliente::calcBMI($_POST['altezza'], $_POST['peso']);
            // Cripto la password
            $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
            // Inserisco nel database i dati
            Cliente::insertNewCliente($_POST, $bmi, $password);
            // Ritorno al login
            header("location: " . URL . "login");
        }
    }

    public function signIn() {
        require_once 'application/models/formCheck.php';
        require_once 'application/models/cliente.php';
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            // Controllo che i campi non siano vuoti
            if (!FormCheck::areSet($_POST)) {
                // Segnalo all'utente l'errore
                FormCheck::phpAlert ('Devono essere riempiti tutti i campi del form.');
                // Ritorno al login
                $this->index();
                return;
            // Controllo se la mail inserita esiste
            } elseif (!Cliente::existsMail($_POST['mail'])) {
                // Segnalo all'utente l'errore
                FormCheck::phpAlert ('La mail utilizzata non é registrata.');
                // Ritorno al login
                $this->index();
                return;
            }
            $hash = Cliente::getPasswordByMail($_POST['mail'],$_POST['password']);
            if (password_verify($_POST['password'], $hash)) {
                // Memorizzo la mail nella sessione
                $_SESSION['mail'] = $_POST['mail'];
                header("location: " . URL . "clienteController");
            } else {
                // Segnalo all'utente l'errore
                FormCheck::phpAlert ('Password errata.');
                // Ritorno al login
                $this->index();
                return;
            }
        }
    }

    public function logout() {
        // Svuoto le variabili di sessione
        session_destroy();
        //Ritorno alla home del sito
        header("location: " . URL);
    }
}
