<?php

class ResponsabileController {

    /**
     * 
     */
    function index() {
        // Se la mail non é del responsabile o se la sessione non é stata registrata
        // l'utente viene reindirizzato alla home
        if (!isset($_SESSION['mail']))
            header("location: " . URL);
        if (strcmp($_SESSION['mail'], ADMIN))
            header("location: " . URL);
        header("location: " . URL . "clienteController/responsabile");
    }

    /**
     * 
     */
    function listaClienti() {
        // Dati
        require_once 'application/models/responsabile.php';
        $r = new Responsabile();
        $clienti = $r->getListaClienti();
        // View
        require 'application/views/_template/header.php';
        require 'application/views/responsabile/listaClienti.php';
        require 'application/views/_template/footer.php';
    }

    /**
     * 
     */
    function listaModifiche() {
        // Dati
        require_once 'application/models/responsabile.php';
        $r = new Responsabile();
        $clienti = $r->getListaModifiche();
        $check = '';
        $method = "listaModificheOnlyDeleted";
        // View
        require 'application/views/_template/header.php';
        require 'application/views/responsabile/listaModifiche.php';
        require 'application/views/_template/footer.php';
    }

    /**
     * 
     */
    function listaModificheOnlyDeleted() {
        // Dati
        require_once 'application/models/responsabile.php';
        $r = new Responsabile();
        $clienti = $r->getListaModificheOnlyDeleted();
        $check = 'checked';
        $method = "listaModifiche";
        // View
        require 'application/views/_template/header.php';
        require 'application/views/responsabile/listaModifiche.php';
        require 'application/views/_template/footer.php';
    }

    /**
     * 
     * @param type $id
     */
    function reimpostaPassword($id) {
        // Riporto l'id del cliente nella pagina 
        // per reimpostare la password
        // View
        require 'application/views/_template/header.php';
        require 'application/views/responsabile/reimpostaPassword.php';
        require 'application/views/_template/footer.php';
    }

    function setPassword($id) {
        // Riporto l'id del cliente per aggiornare la sua password
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            // Controllo che la password sia settata
            $password = isset($_POST['confPwd']) ? $_POST['confPwd'] : null;
            // Se non lo é ritorno alla home
            if ($password == null)
                header("location: " . URL . "clienteController/responsabile");
            // Dati
            require_once 'application/models/responsabile.php';
            $r = new Responsabile();
            // Faccio l'update criptando la password
            $r->updatePassword($id, password_hash($password, PASSWORD_DEFAULT));
            header("location: " . URL . "clienteController/responsabile");
        }
    }

    function eliminaCliente($id) {
        // Dati
        require_once 'application/models/responsabile.php';
        $r = new Responsabile();
        $r->deleteCliente($id);
        header("location: " . URL . "responsabileController/listaModifiche");
    }

    function riabilitaCliente($id) {
        // Dati
        require_once 'application/models/responsabile.php';
        $r = new Responsabile();
        $r->riabilitaCliente($id);
        header("location: " . URL . "responsabileController/listaModifiche");
    }

    function modificaDati($id) {
        // Riporto l'id del cliente nella pagina 
        // Richiamo la classe del responsabile
        require_once 'application/models/responsabile.php';
        // Creo l'oggetto responsabile
        $r = new Responsabile();
        // Mi faccio restituire la mail del cliente dal responsabile
        $mailCliente = $r->getClienteMail($id);
        // Richiamo la classe cliente
        require_once 'application/models/cliente.php';
        // Creo l'oggetto cliente
        $c = new Cliente($mailCliente);
        // Prendo i dati del cliente
        $pesoCliente = $c->getMassa();
        $altezzaCliente = $c->getAltezza();
        // View
        require 'application/views/_template/header.php';
        require 'application/views/responsabile/modificaDati.php';
        require 'application/views/_template/footer.php';
    }

    /**
     * 
     * @param type $id
     */
    function changeDataCliente($id) {
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            // Controllo che i campi non siano vuoti
            $mail = isset($_POST['mail']) ? $_POST['mail'] : null;
            $peso = isset($_POST['peso']) ? $_POST['peso'] : null;
            $altezza = isset($_POST['altezza']) ? $_POST['altezza'] : null;
            // Se anche un campo é vuoto ritorno alla home del responsabile
            if ($mail == null || $peso == null || $altezza == null)
                header("location: " . URL . "clienteController/responsabile");

            // Richiamo la classe cliente
            require_once 'application/models/cliente.php';
            // Calcolo il BMI
            $bmi = Cliente::calcBMI($altezza, $peso);
            // Richiamo la classe del responsabile
            require_once 'application/models/responsabile.php';
            // Creo l'oggetto responsabile
            $r = new Responsabile();
            // Aggiorno i nuovi dati del cliente
            $r->updateDataCliente($id, $altezza, $peso, $BMI, $mail);
            // Ritorno alla pagina di modifica
            header("location: " . URL . "responsabileController/listaModifiche");
        }
    }

    /**
     * 
     */
    function listaAttrezzi() {
        // Dati
        require_once 'application/models/attrezzo.php';
        $att = new Attrezzo();
        $data = $att->getAll();
        // View
        require 'application/views/_template/header.php';
        require 'application/views/responsabile/listaAttrezzi.php';
        require 'application/views/_template/footer.php';
    }

    /**
     * 
     * @param type $id
     */
    function statistiche($id) {
        // Richiamo la classe cliente
        require_once 'application/models/cliente.php';
        $row = Cliente::getStatistiche($id);
        $bmi = array();
        $date = array();
        for ($index = 0; $index < count($row); $index++) {
            array_push($bmi, $row[$index]['BMI']);
            array_push($date, date_format(new DateTime($row[$index]['data']), 'd-m-Y'));
        }
        // View
        require 'application/views/_template/header.php';
        require 'application/views/cliente/graficoStatistiche.php';
        require 'application/views/_template/footer.php';
    }

    /**
     * 
     */
    function listaStatistiche() {
        // Dati
        require_once 'application/models/responsabile.php';
        $r = new Responsabile();
        $clienti = $r->getListaModifiche();
        // View
        require 'application/views/_template/header.php';
        require 'application/views/responsabile/listaStatistiche.php';
        require 'application/views/_template/footer.php';
    }

    /**
     * 
     * @param type $idAttrezzo
     */
    function creazioneEsercizio($idAttrezzo = null) {
        // Dati
        // Prendo gli attrezzi
        require_once 'application/models/attrezzo.php';
        $att = new Attrezzo();
        $data = $att->getAll();
        // Controllo se l'id dell'attrezzo é diverso da NULL
        // se lo é prendo dal Database i suoi parametri
        if ($idAttrezzo != null) {
            // Setto id ad $att
            $att->setID($idAttrezzo);
            $param = $att->getParametri();
        }
        // View
        require 'application/views/_template/header.php';
        require 'application/views/responsabile/creazioneEsercizio.php';
        require 'application/views/_template/footer.php';
    }

    /**
     * 
     */
    function insertEsercizio() {
        // Model
        require_once 'application/models/formCheck.php';
        require_once 'application/models/esercizio.php';
        // Variables
        $arrayV = [];
        $arrayK = [];
        $esercizio;
        $idAttrezzo;
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
//            print_r($_POST);
            // Controllo che tutti i campi non siano vuoti
            if (FormCheck::areSet($_POST)) {
                foreach ($_POST as $key => $value) {
                    switch ($key) {
                        case 'nomeEsercizio':
                            // Se la chiave é nomeEsercizio creo un oggetto Esercizio e assegno il valore
                            $esercizio = new Esercizio($value);
                            break;
                        case 'idAttrezzo':
                            $idAttrezzo = $value;
                            break;
                        default:
                            array_push($arrayV, $value);
                            array_push($arrayK, $key);
                            break;
                    }
                }
                // Creo un nuovo array chiave valore con solo i parametri
                $values = array_combine($arrayK, $arrayV);
                // Inserisco l'esercizio del Database
                $esercizio->insertEsercizio();
                $esercizio->insertEsercizioValore($idAttrezzo, $values);
                // Ritorno alla pagina home
                header("location: " . URL . "responsabileController");
            }
        }
    }

    /**
     * 
     */
    function visualizzaSchede() {
        require_once 'application/models/scheda.php';
        $scheda = new Scheda();
        $table = $scheda->visualizzaSchede();
        // View
        require 'application/views/_template/header.php';
        require 'application/views/responsabile/visualizzaSchede.php';
        require 'application/views/_template/footer.php';
    }

    function creazioneScheda() {
        $counterEsercizio = 0;
        // View
        require 'application/views/_template/header.php';
        require 'application/views/responsabile/creazioneScheda.php';
        require 'application/views/_template/footer.php';
    }

}
