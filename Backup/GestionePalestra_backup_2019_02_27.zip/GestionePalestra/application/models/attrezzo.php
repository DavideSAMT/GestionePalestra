<?php
require_once 'application/models/connectionDb.php';
/**
 * Classe per gestire un attrezzo
 */
class Attrezzo {
    /**
     * Connessione al database
     * @var type ConnectionDb
     */
    private $db;
    /**
     * Id dell'attrezzo
     * @var type int
     */
    private $id;
    /**
     * Nome dell'atrezzo
     * @var type string
     */
    private $nome;
    /**
     * Descrizione dell'attrezzo
     * @var type string
     */
    private $descrizione;
    /**
     * Path dell'immagine
     * @var type string
     */
    private $path;
    /**
     * Id della tipologia
     * @var type int
     */
    private $id_tipologia;

    function __construct() {
        $this->db = new ConnectionDb();
    }
    /**
     * 
     * @return type
     */
    function getAll() {
        $sql = 'SELECT * FROM attrezzo';
        $result = mysqli_query($this->db->getConnection(), $sql);
        $array = mysqli_fetch_all($result, MYSQLI_ASSOC);
        return $array;
    }
    /**
     * 
     * @param type $id
     */
    function setID($id) {
        $this->id = $id;
    }
    /**
     * 
     * @return type
     */
    function getDescrizione() {
        $sql = 'SELECT Descrizione FROM attrezzo WHERE id = '.$this->id;
        $result = mysqli_query($this->db->getConnection(), $sql);
        $array = mysqli_fetch_all($result, MYSQLI_ASSOC);
        return $array[0]['Descrizione'];
    }
    /**
     * 
     * @return type
     */
    function getLink() {
        $sql = 'SELECT Link FROM attrezzo WHERE id = '.$this->id;
        $result = mysqli_query($this->db->getConnection(), $sql);
        $array = mysqli_fetch_all($result, MYSQLI_ASSOC);
        return $array[0]['Link'];
    }
    /**
     * 
     * @return type
     */
    function getNome() {
        $sql = 'SELECT Nome FROM attrezzo WHERE id = '.$this->id;
        $result = mysqli_query($this->db->getConnection(), $sql);
        $array = mysqli_fetch_all($result, MYSQLI_ASSOC);
        return $array[0]['Nome'];
    }
    
    function getParametri() {
        $sql = 'SELECT Parametro FROM parametro_Attrezzo WHERE id_attrezzo = '.$this->id;
        $result = mysqli_query($this->db->getConnection(), $sql);
        $array = mysqli_fetch_all($result, MYSQLI_ASSOC);
        return $array;
    }
}