<?php

require_once 'application/models/connectionDb.php';

class Cliente {

    /**
     *
     * @var type 
     */
    private $mail;

    /**
     * 
     * @param type $mail
     */
    public function __construct($mail) {
        $this->mail = $mail;
    }

    /**
     * 
     * @param type $altezza
     * @param type $peso
     * @return type
     */
    public static function calcBMI($altezza, $peso) {
        return ($peso / ($altezza * $altezza));
    }

    /**
     * 
     * @param type $array
     * @param type $bmi
     * @param type $password
     */
    public static function insertNewCliente($array, $bmi, $password) {
        // Connessione al DB
        $db = new ConnectionDb();
        $conn = $db->getConnection();
        // Preparo la query
        $stmt = $conn->prepare("INSERT INTO cliente (Nome, Cognome, Massa, Altezza, BMI, Mail, Password) VALUES (?, ?, ?, ?, ?, ? ,?)");
        $stmt->bind_param(
                "ssiddss", $array['nome'], $array['cognome'], $array['peso'], $array['altezza'], $bmi, $array['mail'], $password
        );
        $stmt->execute();
        $stmt->close();
        $conn->close();
    }

    /**
     * 
     * @param type $mail
     * @return boolean
     */
    public static function existsMail($mail) {
        // Connessione al DB
        $db = new ConnectionDb();
        $conn = $db->getConnection();
        // Faccio la query
        $query = "SELECT Mail FROM cliente WHERE Mail LIKE '$mail'";
        $result = $conn->query($query);
        $row = $result->num_rows;
        $result->close();
        $conn->close();
        if ($row == 0)
            return false;
        return true;
    }

    /**
     * 
     * @param type $mail
     * @param type $password
     * @return type
     */
    public static function getPasswordByMail($mail) {
        // Connessione al DB
        $db = new ConnectionDb();
        $conn = $db->getConnection();
        // Faccio la query
        $query = "SELECT Password FROM cliente WHERE Mail LIKE '$mail'";
        $result = $conn->query($query);
        $row = $result->fetch_assoc();
        $conn->close();
        return $row['Password'];
    }

    /**
     * 
     * @return string
     */
    public function getFullName() {
        // Connessione al DB
        $db = new ConnectionDb();
        $conn = $db->getConnection();
        // Faccio la query
        $query = "SELECT Nome, Cognome FROM cliente WHERE Mail LIKE '$this->mail'";
        $result = $conn->query($query);
        $row = $result->fetch_assoc();
        $fullName = $row['Nome'] . " " . $row['Cognome'];
        $conn->close();
        return $fullName;
    }

    /**
     * 
     * @return type
     */
    public function getAltezza() {
        // Connessione al DB
        $db = new ConnectionDb();
        $conn = $db->getConnection();
        // Faccio la query
        $query = "SELECT Altezza FROM cliente WHERE Mail LIKE '$this->mail'";
        $result = $conn->query($query);
        $row = $result->fetch_assoc();
        $conn->close();
        return $row['Altezza'];
    }

    /**
     * 
     * @return type
     */
    public function getMassa() {
        // Connessione al DB
        $db = new ConnectionDb();
        $conn = $db->getConnection();
        // Faccio la query
        $query = "SELECT Massa FROM cliente WHERE Mail LIKE '$this->mail'";
        $result = $conn->query($query);
        $row = $result->fetch_assoc();
        $conn->close();
        return $row['Massa'];
    }

    /**
     * 
     * @return type
     */
    public function getBMI() {
        // Connessione al DB
        $db = new ConnectionDb();
        $conn = $db->getConnection();
        // Faccio la query
        $query = "SELECT BMI FROM cliente WHERE Mail LIKE '$this->mail'";
        $result = $conn->query($query);
        $row = $result->fetch_assoc();
        $conn->close();
        return $row['BMI'];
    }

    /**
     * 
     * @return type
     */
    public function getId() {
        // Connessione al DB
        $db = new ConnectionDb();
        $conn = $db->getConnection();
        // Faccio la query
        $query = "SELECT id FROM cliente WHERE Mail LIKE '$this->mail'";
        $result = $conn->query($query);
        $row = $result->fetch_assoc();
        $conn->close();
        return $row['id'];
    }

    public static function getStatistiche($id) {
        // Connessione al DB
        $db = new ConnectionDb();
        $conn = $db->getConnection();
        // Faccio la query
        $query = "SELECT BMI,data FROM statistiche WHERE id_cliente LIKE $id";
        $result = $conn->query($query);
        $row = mysqli_fetch_all($result, MYSQLI_ASSOC);
        $conn->close();
        return $row;
    }

}
