<?php

/**
 * Classe per connettersi al database
 */
class ConnectionDb {
    /**
     * Hostname del server mysql
     * @var type string
     */
    private $host = 'localhost';
    /**
     * Username dell'utente che opera con il database
     * @var type string
     */
    private $user = 'root';
    /**
     * Password dello Username
     * @var type string
     */
    private $password = '';
    /**
     * Database che utilizzo
     * @var type string
     */
    private $database = 'gestionepalestra';
    /**
     * Porta per connettersi al server mysql
     * @var type int
     */
    private $port = 3306;
    /**
     * Connesione al server mysql
     * @var type MySQLi link identifier
     */
    private $conn = null;
    /**
     * Costruttore della classe
     * che fa una connessione al database
     */
    function __construct() {
        
    }
    /**
     * Funzione che chiude la connesione con il database
     */
    function close() {
        mysqli_close($this->conn);
    }
    /**
     * Ritorna la connessione al database
     * @return type MySQLi link identifier
     */
    function getConnection() {
        if ($this->conn == null) $this->conn = mysqli_connect($this->host, $this->user, $this->password, $this->database, $this->port);
        return $this->conn;
    }
    
    

}