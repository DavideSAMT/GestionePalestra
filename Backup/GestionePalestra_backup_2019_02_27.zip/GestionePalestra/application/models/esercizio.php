<?php
// Import
require_once 'application/models/connectionDb.php';
// ############################################################################################
class Esercizio {
    /**
     *
     * @var type 
     */
    private $db;
    /**
     *
     * @var type 
     */
    private $nome;
    /**
     * 
     */
    function __construct($nome) {
        $this->nome = $nome;
        $this->db = new ConnectionDb();
    }
    /**
     * 
     */
    function insertEsercizio() {
        $query = "INSERT INTO esercizio(Nome) VALUES ('$this->nome')";
        mysqli_query($this->db->getConnection(), $query);
    }
    /**
     * 
     * @return type
     */
    private function getId() {
        $query = "SELECT id FROM esercizio WHERE Nome LIKE '$this->nome'";
        $result = mysqli_query($this->db->getConnection(), $query);
        $array = mysqli_fetch_all($result, MYSQLI_ASSOC);
        return $array[0]['id'];
    }
    /**
     * 
     * @param type $idAttrezzo
     */
    private function getIdsParAttByIdAttrezzo($idAttrezzo) {
        $query = "SELECT id FROM parametro_attrezzo WHERE id_attrezzo = $idAttrezzo";
        $result = mysqli_query($this->db->getConnection(), $query);
        $array = mysqli_fetch_all($result, MYSQLI_ASSOC);
        return $array;
    }
    /**
     * 
     * @param type $idAttrezzo
     * @param type $values
     */
    function insertEsercizioValore($idAttrezzo, $values) {
        $idEsercizio = $this->getId();
        $idsParAtt = $this->getIdsParAttByIdAttrezzo($idAttrezzo);
        $values = array_values($values);
        for ($index = 0; $index < count($idsParAtt); $index++) {
            $query = "INSERT INTO esercizio_valore(Valore, id_par_att, id_esercizio) "
                    . "VALUES (".$values[$index].",".$idsParAtt[$index]['id'].",".$idEsercizio.")";
            mysqli_query($this->db->getConnection(), $query);
        }
    }
}