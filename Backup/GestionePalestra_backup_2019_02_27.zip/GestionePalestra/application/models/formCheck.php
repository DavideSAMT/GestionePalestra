<?php

/**
 * 
 */
class FormCheck {

    /**
     * 
     * @param Array $array
     * @return boolean
     */
    public static function areSet($array) {
        foreach ($array as $key => $value) {
            if (!isset($value)) {
                return false;
            }
        }
        return true;
    }
    /**
     * 
     * @param string $msg
     */
    public static function phpAlert($msg) {
        echo '<script type="text/javascript">alert("' . $msg . '")</script>';
    }

}
