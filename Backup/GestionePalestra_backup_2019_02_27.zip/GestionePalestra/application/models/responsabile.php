<?php

require_once 'application/models/connectionDb.php';

class Responsabile {

    private $db;

    function __construct() {
        // Connessione al DB
        $this->db = new ConnectionDb();
    }

    /**
     * 
     * @return type
     */
    public function getListaClienti() {
        $conn = $this->db->getConnection();
        // Faccio la query
        $query = "SELECT Nome,Cognome,Massa,Altezza,BMI,Mail FROM cliente WHERE id NOT LIKE 0 AND Deleted IS NULL ORDER BY Nome ASC";
        $result = $conn->query($query);
        $row = mysqli_fetch_all($result, MYSQLI_ASSOC);
        $conn->close();
        return $row;
    }

    /**
     * 
     * @return type
     */
    public function getListaModifiche() {
        $conn = $this->db->getConnection();
        // Faccio la query
        $query = "SELECT id,Nome,Cognome,Mail,Deleted FROM cliente WHERE id NOT LIKE 0 ORDER BY Nome ASC";
        $result = $conn->query($query);
        $row = mysqli_fetch_all($result, MYSQLI_ASSOC);
        $conn->close();
        return $row;
    }
    /**
     * 
     * @return type
     */
    public function getListaModificheOnlyDeleted() {
        $conn = $this->db->getConnection();
        // Faccio la query
        $query = "SELECT id,Nome,Cognome,Mail,Deleted FROM cliente WHERE id NOT LIKE 0 AND Deleted IS NOT NULL ORDER BY Nome ASC";
        $result = $conn->query($query);
        $row = mysqli_fetch_all($result, MYSQLI_ASSOC);
        $conn->close();
        return $row;
    }

    /**
     * 
     * @param type $id
     * @param type $password
     */
    public function updatePassword($id, $password) {
        $conn = $this->db->getConnection();
        // Faccio la query
        $query = "UPDATE cliente SET Password = '$password' WHERE id = $id";
        $conn->query($query);
        $conn->close();
    }

    /**
     * 
     * @param type $id$
     */
    public function deleteCliente($id) {
        $conn = $this->db->getConnection();
        $data = new DateTime();
        $data = $data->format('Y-m-d');
        // Faccio la query
        $query = "UPDATE cliente SET Deleted = '$data' WHERE id = $id";
        $conn->query($query);
        $conn->close();
    }

    /**
     * 
     * @param type $id
     */
    public function riabilitaCliente($id) {
        $conn = $this->db->getConnection();
        // Faccio la query
        $query = "UPDATE cliente SET Deleted = NULL WHERE id = $id";
        $conn->query($query);
        $conn->close();
    }

    /**
     * 
     * @param type $id
     * @return type
     */
    public function getClienteMail($id) {
        $conn = $this->db->getConnection();
        // Faccio la query
        $query = "SELECT Mail FROM cliente WHERE id = $id";
        $result = $conn->query($query);
        $row = mysqli_fetch_all($result, MYSQLI_ASSOC);
        $conn->close();
        return $row[0]['Mail'];
    }
    /**
     * 
     * @param type $id
     * @param type $altezza
     * @param type $peso
     * @param type $BMI
     * @param type $mail
     */
    public function updateDataCliente($id, $altezza, $peso, $BMI, $mail) {
        $conn = $this->db->getConnection();
        // Faccio le query
        $query = "UPDATE cliente SET Altezza = $altezza WHERE id = $id";
        $conn->query($query);
        $query = "UPDATE cliente SET Massa = $peso WHERE id = $id";
        $conn->query($query);
        $query = "UPDATE cliente SET BMI = $BMI WHERE id = $id";
        $conn->query($query);
        $query = "UPDATE cliente SET Mail = '$mail' WHERE id = $id";
        $conn->query($query);
        $conn->close();
    }

}
