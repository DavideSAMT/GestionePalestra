<?php
require_once 'application/models/connectionDb.php';
class Scheda {
    /**
     *
     * @var type 
     */
    private $db;
    /**
     *
     * @var type 
     */
    private $idCliente;
    /**
     * 
     */
    function __construct() {
        $this->db = new ConnectionDb();
    }
    /**
     * 
     */
    function getAll() {
        $sql = 'SELECT * FROM scheda';
        $result = mysqli_query($this->db->getConnection(), $sql);
        $array = mysqli_fetch_all($result, MYSQLI_ASSOC);
        return $array;
    }
    /**
     * 
     * @param type $id
     */
    function setIdCliente($idCliente) {
        $this->idCliente = $idCliente;
    }
    /**
     * 
     * @return type
     */
    function getFromCliente() {
        $sql = 'SELECT * FROM scheda WHERE id_cliente = '.$this->idCliente." ORDER BY id DESC";
        $result = mysqli_query($this->db->getConnection(), $sql);
        $array = mysqli_fetch_all($result, MYSQLI_ASSOC);
        return $array;
    }
    
    function visualizzaSchede() {
        $sql = 'SELECT scheda.id, scheda.Titolo, CONCAT(cliente.Nome," ", cliente.Cognome) AS cliente '
                . 'FROM scheda INNER JOIN cliente ON cliente.id = scheda.id_cliente';
        $result = mysqli_query($this->db->getConnection(), $sql);
        $array = mysqli_fetch_all($result, MYSQLI_ASSOC);
        return $array;
    }
}