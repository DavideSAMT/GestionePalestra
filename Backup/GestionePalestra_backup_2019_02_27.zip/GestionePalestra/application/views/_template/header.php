<!DOCTYPE html>
<html>
    <head>
        <!-- Title Website -->
        <title>
            Gestione Palestra
        </title>
        <!-- Favicon -->
        <link rel="icon" type="image/png" href="<?php echo URL ?>application/img/icon.png" />
        <!-- Boobstrap CSS -->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" 
              integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" 
              integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
        <!-- Header CSS -->
        <link rel="stylesheet" href="<?php echo URL ?>application/css/header.css">
        <!-- Scrollbar CSS -->
        <link rel="stylesheet" href="<?php echo URL ?>application/css/scrollbar.css">
        <!-- Content CSS -->
        <link rel="stylesheet" href="<?php echo URL ?>application/css/content.css">
        <!-- Footer CSS -->
        <link rel="stylesheet" href="<?php echo URL ?>application/css/footer.css">
        <meta http-equiv="content-type" content="text/html; charset=utf-8">
    </head>
    <body>