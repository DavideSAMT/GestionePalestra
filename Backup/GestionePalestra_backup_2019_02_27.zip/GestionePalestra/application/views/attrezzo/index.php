<div class="wrapper">
    <header>
        <nav>
            <div class="menu-icon">
                <i class="fa fa-bars fa-2x"></i>
            </div>
            <div class="logo">
                GESTIONE PALESTRA
            </div>
            <div class="menu">
                <ul>
                    <li><a href="<?php echo URL ?>clienteController">Informazioni</a></li>
                    <li><a href="#">Mie schede</a></li>
                    <li><a href="<?php echo URL ?>login/logout">Logout</a></li>
                </ul>
            </div>
        </nav>
    </header>
    <div class="content">
        <div class="container">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <h1>
                            <?php echo $nome ?>
                        </h1>
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <img src="<?php echo URL ?>application/img/<?php echo $link ?>" style="width: 100%;">
                    </div>
                    <div class="col">
                        <?php echo $desc ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>