<div class="wrapper">
    <header>
        <nav>
            <div class="menu-icon">
                <i class="fa fa-bars fa-2x"></i>
            </div>
            <div class="logo">
                GESTIONE PALESTRA
            </div>
            <div class="menu">
                <ul>
                    <li><a href="<?php echo URL ?>responsabileController">Home Responsabile</a></li>
                    <li><a href="<?php echo URL ?>login/logout">Logout</a></li>
                </ul>
            </div>
        </nav>
    </header>

    <div class="content">
        <div class="container">
            <canvas id="myChart"></canvas>
        </div>
    </div>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.4.0/Chart.min.js"></script>
<script>
    var ctx = document.getElementById('myChart').getContext('2d');
    var chart = new Chart(ctx, {
        // The type of chart we want to create
        type: 'line',

        // The data for our dataset
        data: {
            labels: ['<?php echo implode("','", $date)?>'],
            datasets: [{
                    label: "BMI",
                    backgroundColor: 'rgba(255, 255, 255, 0)',
                    borderColor: 'rgb(255, 0, 0)',
                    data: ['<?php echo implode("','", $bmi)?>'],
                }]
        },

        // Configuration options go here
        options: {}
    });
</script>