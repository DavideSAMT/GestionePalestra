<div class="wrapper">
    <header>
        <nav>
            <div class="menu-icon">
                <i class="fa fa-bars fa-2x"></i>
            </div>
            <div class="logo">
                GESTIONE PALESTRA
            </div>
            <div class="menu">
                <ul>
                    <li><a href="#">Informazioni</a></li>
                    <li><a href="<?php echo URL ?>clienteController/mieSchede">Mie schede</a></li>
                    <li><a href="<?php echo URL ?>login/logout">Logout</a></li>
                </ul>
            </div>
        </nav>
    </header>
    <div class="content">
        <div class="container">
            <br>
            <center>
                <div class="row">
                    <div class="col-sm"></div>
                    <div class="col-sm">
                        <h1><?php echo $fullName ?></h1>
                    </div>
                    <div class="col-sm"></div>
                </div>
                <br>
                <div class="row">
                    <div class="col-sm">
                        <div class="item">
                            <h2><?php echo $altezza ?> m</h2>
                            <span>Altezza</span>
                        </div>
                    </div>
                    <div class="col-sm">
                        <div class="item">
                            <h2><?php echo $massa ?> kg</h2>
                            <span>Massa</span>
                        </div>
                    </div>
                    <div class="col-sm">
                        <div class="item">
                            <h2><?php echo $BMI ?> kg/m2</h2>
                            <span>BMI</span>
                        </div>
                    </div>
                </div>
            </center>
            <br>
        </div>
    </div>
</div>