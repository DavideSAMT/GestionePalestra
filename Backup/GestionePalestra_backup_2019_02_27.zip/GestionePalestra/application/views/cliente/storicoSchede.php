<div class="wrapper">
    <header>
        <nav>
            <div class="menu-icon">
                <i class="fa fa-bars fa-2x"></i>
            </div>
            <div class="logo">
                GESTIONE PALESTRA
            </div>
            <div class="menu">
                <ul>
                    <li><a href="<?php echo URL ?>clienteController">Informazioni</a></li>
                    <li><a href="#">Mie schede</a></li>
                    <li><a href="<?php echo URL ?>login/logout">Logout</a></li>
                </ul>
            </div>
        </nav>
    </header>
    <div class="content">
        <div class="container" style="padding: 0;">
            <table class="table" style="width: 100%;">
                <thead class="thead-dark">
                    <tr>
                        <th scope="col">Titolo</th>
                        <th scope="col">Data di scadenza</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($schedeCliente as $value): ?>
                        <tr>
                            <td><?php echo $value['Nome'] ?></td>
                            <td>
                                <?php
                                if ($value['Data_Scadenza'] != null) {
                                    $date = date_create($value['Data_Scadenza']);
                                    echo date_format($date, "d/m/Y");
                                } else {
                                    echo "ATTIVA";
                                }
                                ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>