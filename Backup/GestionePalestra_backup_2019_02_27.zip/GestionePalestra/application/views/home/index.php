<div class="wrapper">
    <header>
        <nav>
            <div class="menu-icon">
                <i class="fa fa-bars fa-2x"></i>
            </div>
            <div class="logo">
                GESTIONE PALESTRA
            </div>
            <div class="menu">
                <ul>
                    <li><a href="#">Home</a></li>
                    <li><a href="<?php echo URL ?>login/">Login</a></li>
                </ul>
            </div>
        </nav>
    </header>
    <div class="content">
        <div class="container" style="background-color: black;">
            <br>
            <?php foreach ($data as $key => $value): ?>
                <?php
                if ($key == 0 || $key % 3 == 0) {
                    echo '<div class="card-columns">';
                }
                ?>
                <div class="card" style="width:auto; height: auto;">
                    <div class="card-body">
                        <h4 class="card-title"><?php echo $value['Nome']; ?></h4>
                        <p class="card-text" style="height: 200px;"><?php echo $value['Descrizione']; ?></p>
                        <button class="btn btn-danger" style="color: #fff" data-toggle="modal" data-target="#box_<?php echo $key ?>">Visualizza</button>
                    </div>
                </div>
                <?php
                if (($key + 1) % 3 == 0) {
                    echo '</div>';
                }
                ?>
            <?php endforeach; ?>
            <br>
        </div>
    </div>
</div>
<!-- Modals -->
<?php foreach ($data as $key => $value): ?>
<div class="modal fade" id="box_<?php echo $key ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <img src="<?php echo URL?>application/img/<?php echo $value['Link']?>" alt="" style="width: 100%;">
            </div>
        </div>
    </div>
</div>
<?php endforeach; ?>
