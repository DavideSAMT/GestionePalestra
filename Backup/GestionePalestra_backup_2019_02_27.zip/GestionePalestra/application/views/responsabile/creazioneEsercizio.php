<div class="wrapper">
    <header>
        <nav>
            <div class="menu-icon">
                <i class="fa fa-bars fa-2x"></i>
            </div>
            <div class="logo">
                GESTIONE PALESTRA
            </div>
            <div class="menu">
                <ul>
                    <li><a href="<?php echo URL ?>responsabileController">Home Responsabile</a></li>
                    <li><a href="<?php echo URL ?>login/logout">Logout</a></li>
                </ul>
            </div>
        </nav>
    </header>
    <div class="content">
        <div class="container" style="padding: 0">
            <form method="POST" action="<?php echo URL ?>responsabileController/insertEsercizio">
                <div class="form-row">
                    <div class="form-group col-md-4">
                        <label for="name">Nome</label>
                        <input type="text" placeholder="Nome esercizio" id="name" name="nomeEsercizio" class="form-control" required>
                    </div>
                    <div class="form-group col-md-4">
                        <label for="inputAttrezzo">Attrezzo</label>
                        <select id="inputAttrezzo" class="form-control" name="idAttrezzo" onchange="javascript:selectId(this)" required>
                            <option selected disabled value="null">Scegli...</option>
                            <!-- STAMPA NOMI ATTREZZI -->
                            <?php for ($i = 0; $i < count($data); $i++): ?>
                                <?php foreach ($data[$i] as $key => $value): ?>
                                    <?php if (!strcmp($key, 'Nome')): ?>
                                        <?php if ($idAttrezzo == $data[$i]['id']): ?>
                                            <option value="<?php echo $data[$i]['id'] ?>" selected>
                                            <?php else: ?>
                                            <option value="<?php echo $data[$i]['id'] ?>">
                                            <?php endif; ?>
                                            <?php echo $value; ?>
                                        </option>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            <?php endfor; ?>
                            <!-- ############################################### -->
                        </select>
                    </div>
                </div>
                <!-- STAMPA DEI PARAMETRI -->
                <?php if ($idAttrezzo != null): ?>
                    <?php for ($i = 0; $i < count($param); $i++): ?>
                        <?php foreach ($param[$i] as $key => $value): ?>
                            <div class="form-group">
                                <label for="input<?php echo $value ?>">
                                    <!-- NOME PARAMETRO -->
                                    <?php echo $value ?>
                                </label><br>
                                <input id="input<?php echo $value ?>" name="<?php echo $value ?>" type="number" min="0" class="form-control">
                            </div>
                        <?php endforeach; ?>
                    <?php endfor; ?>
                <?php endif; ?>
                <!-- ############################################### -->
                <button type="submit" class="btn btn-danger" disabled id="btn">Crea esercizio</button>
            </form>
        </div>
    </div>
</div>
<script>
    var url = "<?php echo URL ?>responsabileController/creazioneEsercizio/";
    function selectId(sel) {
        var id = sel.value;
        window.location = url + id;
    }
    
    window.addEventListener('load', function() {
         if (document.getElementById('inputAttrezzo').value != 'null') {
            document.getElementById('btn').removeAttribute("disabled");
        }
    });
</script>