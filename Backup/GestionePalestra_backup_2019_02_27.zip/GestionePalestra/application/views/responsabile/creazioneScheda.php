<div class="wrapper">
    <header>
        <nav>
            <div class="menu-icon">
                <i class="fa fa-bars fa-2x"></i>
            </div>
            <div class="logo">
                GESTIONE PALESTRA
            </div>
            <div class="menu">
                <ul>
                    <li><a href="<?php echo URL ?>responsabileController">Home Responsabile</a></li>
                    <li><a href="<?php echo URL ?>login/logout">Logout</a></li>
                </ul>
            </div>
        </nav>
    </header>
    <div class="content">
        <div class="container" style="padding: 0">
            <form method="POST" action="<?php echo URL ?>responsabileController/insertEsercizio">
                <div class="form-row">
                    <div class="form-group col-md-4">
                        <label for="name">Titolo</label>
                        <input type="text" placeholder="Titolo scheda" id="name" name="nomeEsercizio" class="form-control" required>
                    </div>
                </div>
                <div class="form-group" id="selects">
                    <label for="name">Esercizi</label>
                    <select class="form-control">
                        <option>ESEMPIO</option>
                    </select>
                </div>
                <div style="text-align: center;">
                    <button type="button" class="btn btn-danger btn-sm" onclick="addEsercizio()">
                        <i class="fas fa-plus"></i>
                    </button>
                    <button type="button" class="btn btn-danger btn-sm" onclick="removeEsercizio()">
                        <i class="fas fa-minus"></i>
                    </button>
                </div>
                <div class="form-group" id="selects">
                    <label for="name">Cliente</label>
                    <select class="form-control">
                        <option>MARIO ROSSI</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-danger" id="btn">Crea scheda</button>
            </form>
        </div>
    </div>
</div>
<script>
    var counterS = 0;
    function addEsercizio() {
        var div = document.getElementById('selects');
        var select = document.createElement('select');
        var option = document.createElement('option');
        var text = document.createTextNode('ESEMPIO');
        option.appendChild(text);
        select.appendChild(option);
        select.setAttribute('class', 'form-control')
        div.appendChild(select);
        counterS++;
    }
    function removeEsercizio() {
        var div = document.getElementById('selects');
        if (counterS > 0) {
            div.removeChild(div.lastChild);
            counterS--;
        }
    }
</script>