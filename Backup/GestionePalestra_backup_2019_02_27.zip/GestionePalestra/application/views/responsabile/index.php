<div class="wrapper">
    <header>
        <nav>
            <div class="menu-icon">
                <i class="fa fa-bars fa-2x"></i>
            </div>
            <div class="logo">
                GESTIONE PALESTRA
            </div>
            <div class="menu">
                <ul>
                    <li><a href="<?php echo URL ?>login/logout">Logout</a></li>
                </ul>
            </div>
        </nav>
    </header>
    <div class="content">
        <div class="container" style="padding: 0; background-color: black;">
            <center>
                <div class="btn-group" role="group" style="width: 20%;">
                    <button id="btnGroupDrop1" type="button" class="btn btn-danger btn-lg btn-block dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Schede
                    </button>
                    <div class="dropdown-menu" aria-labelledby="btnGroupDrop1">
                        <a class="dropdown-item" href="<?php echo URL?>responsabileController/visualizzaSchede">Visualizza schede</a>
                        <a class="dropdown-item" href="<?php echo URL?>responsabileController/creazioneScheda">Crea nuova scheda</a>
                    </div>
                </div>
                <div class="btn-group" role="group" style="width: 20%;">
                    <button id="btnGroupDrop2" type="button" class="btn btn-danger btn-lg btn-block dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Esercizi
                    </button>
                    <div class="dropdown-menu" aria-labelledby="btnGroupDrop2">
                        <a class="dropdown-item" href="<?php echo URL?>responsabileController/creazioneEsercizio">Crea nuovo esercizio</a>
                    </div>
                </div>
                <div class="btn-group" role="group" style="width: 20%;">
                    <button id="btnGroupDrop3" type="button" class="btn btn-danger btn-lg btn-block dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Attrezzi
                    </button>
                    <div class="dropdown-menu" aria-labelledby="btnGroupDrop3">
                        <a class="dropdown-item" href="<?php echo URL?>responsabileController/listaAttrezzi">Visualizza attrezzi</a>
                    </div>
                </div>
                <div class="btn-group" role="group" style="width: 20%;">
                    <button id="btnGroupDrop3" type="button" class="btn btn-danger btn-lg btn-block dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Clienti
                    </button>
                    <div class="dropdown-menu" aria-labelledby="btnGroupDrop3">
                        <a class="dropdown-item" href="<?php echo URL?>responsabileController/listaClienti">Visualizza clienti</a>
                        <a class="dropdown-item" href="<?php echo URL?>responsabileController/listaStatistiche">Statistiche clienti</a>
                        <a class="dropdown-item" href="<?php echo URL?>responsabileController/listaModifiche">Gestisci clienti</a>
                    </div>
                </div>
            </center>
        </div>
    </div>
</div>