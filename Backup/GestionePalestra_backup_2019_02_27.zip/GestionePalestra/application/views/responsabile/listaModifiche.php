<div class="wrapper">
    <header>
        <nav>
            <div class="menu-icon">
                <i class="fa fa-bars fa-2x"></i>
            </div>
            <div class="logo">
                GESTIONE PALESTRA
            </div>
            <div class="menu">
                <ul>
                    <li><a href="<?php echo URL ?>responsabileController">Home Responsabile</a></li>
                    <li><a href="<?php echo URL ?>login/logout">Logout</a></li>
                </ul>
            </div>
        </nav>
    </header>
    <div class="content">
        <div class="container" style="padding: 0">
            <input class="form-control input-lg" id="bar" type="text" placeholder="Ricerca per nome..." onkeyup="filter()">
            <div class="form-check">
                <form style="float: left;" method="POST" action="<?php echo URL?>responsabileController/<?php echo $method?>">
                    <input type="checkbox" id="check" onclick="this.form.submit();" <?php echo $check?>>
                </form>
                <label class="form-check-label" for="exampleCheck1">Solo eliminati</label>    
            </div>
            <table class="table" style="width: 100%;">
                <thead class="thead-dark">
                    <tr>
                        <th scope="col">Nome</th>
                        <th scope="col">Cognome</th>
                        <th scope="col">Mail</th>
                        <th scope="col"></th>
                        <th scope="col"></th>
                        <th scope="col"></th>
                    </tr>
                </thead>
                <tbody id="tb">
                    <?php for ($i = 0; $i < count($clienti); $i++): ?>
                        <tr>
                            <?php foreach ($clienti[$i] as $key => $value): ?>
                                <?php if (strcmp($key, 'id') && strcmp($key, 'Deleted')): ?>
                                    <td><?php echo $value; ?></td>
                                <?php endif; ?>
                            <?php endforeach; ?>
                            <td>
                                <a href="<?php echo URL ?>responsabileController/modificaDati/<?php echo $clienti[$i]['id'] ?>">
                                    <button type="button" class="btn btn-dark">Modifica dati</button>
                                </a>
                            </td>
                            <td>
                                <a href="<?php echo URL ?>responsabileController/reimpostaPassword/<?php echo $clienti[$i]['id'] ?>">
                                    <button type="button" class="btn btn-dark">Reimposta password</button>
                                </a>
                            </td>
                            <td>
                                <?php if ($clienti[$i]['Deleted'] != null): ?>
                                    <a href="<?php echo URL ?>responsabileController/riabilitaCliente/<?php echo $clienti[$i]['id'] ?>">
                                        <button type="button" class="btn btn-success">&#10004;</button>
                                    </a>
                                <?php else: ?>
                                    <button type="button" class="btn btn-danger" 
                                            data-toggle="modal" data-target="#m<?php echo $clienti[$i]['id'] ?>">
                                        &#x2716;
                                    </button>
                                    <!-- Modal -->
                                    <div class="modal fade" id="m<?php echo $clienti[$i]['id'] ?>" role="dialog">
                                        <div class="modal-dialog">
                                            <!-- Modal content-->
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h4 class="modal-title">Sei sicuro di eliminare questo cliente?</h4>
                                                </div>
                                                <div class="modal-footer">
                                                    <a href="<?php echo URL ?>responsabileController/eliminaCliente/<?php echo $clienti[$i]['id'] ?>">
                                                        <button type="button" class="btn btn-danger">SI</button>
                                                    </a>
                                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Annulla</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endfor; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>