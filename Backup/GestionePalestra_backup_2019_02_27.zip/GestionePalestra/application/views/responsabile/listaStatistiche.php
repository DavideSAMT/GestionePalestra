<div class="wrapper">
    <header>
        <nav>
            <div class="menu-icon">
                <i class="fa fa-bars fa-2x"></i>
            </div>
            <div class="logo">
                GESTIONE PALESTRA
            </div>
            <div class="menu">
                <ul>
                    <li><a href="<?php echo URL ?>responsabileController">Home Responsabile</a></li>
                    <li><a href="<?php echo URL ?>login/logout">Logout</a></li>
                </ul>
            </div>
        </nav>
    </header>
    <div class="content">
        <div class="container" style="padding: 0">
            <input class="form-control input-lg" id="bar" type="text" placeholder="Ricerca per nome..." onkeyup="filter()">
            <table class="table" style="width: 100%;">
                <thead class="thead-dark">
                    <tr>
                        <th scope="col">Nome</th>
                        <th scope="col">Cognome</th>
                        <th scope="col">BMI</th>
                    </tr>
                </thead>
                <tbody id="tb">
                    <?php for ($i = 0; $i < count($clienti); $i++): ?>
                        <tr>
                            <?php foreach ($clienti[$i] as $key => $value): ?>
                                <?php if (strcmp($key, 'id') && strcmp($key, 'Deleted') && strcmp($key, 'Mail')): ?>
                                    <td><?php echo $value; ?></td>
                                <?php endif; ?>
                            <?php endforeach; ?>
                            <td>
                                <a href="<?php echo URL ?>responsabileController/statistiche/<?php echo $clienti[$i]['id'] ?>">
                                    <button type="button" class="btn btn-dark">Visualizza Grafico</button>
                                </a>
                            </td>
                        </tr>
                    <?php endfor; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>