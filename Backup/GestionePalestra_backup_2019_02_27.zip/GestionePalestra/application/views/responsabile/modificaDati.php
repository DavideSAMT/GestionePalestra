<div class="wrapper">
    <header>
        <nav>
            <div class="menu-icon">
                <i class="fa fa-bars fa-2x"></i>
            </div>
            <div class="logo">
                GESTIONE PALESTRA
            </div>
            <div class="menu">
                <ul>
                    <li><a href="<?php echo URL ?>responsabileController">Home Responsabile</a></li>
                    <li><a href="<?php echo URL ?>login/logout">Logout</a></li>
                </ul>
            </div>
        </nav>
    </header>
    <div class="content">
        <div class="container">
            <br>
            <form method="POST" action="<?php echo URL ?>responsabileController/changeDataCliente/<?php echo $id ?>">
                <div class="form-group">
                    <label for="mailCliente">Email cliente</label>
                    <input type="email" class="form-control" name="mail" id="mailCliente" 
                           aria-describedby="email" placeholder="Inserisci mail..." value="<?php echo $mailCliente ?>" required>
                </div>
                <div class="form-group">
                    <label for="peso">Massa cliente (Kg)</label>
                    <input type="number" name="peso" id="peso" tabindex="1" 
                           class="form-control" placeholder="Massa (Kg)" value="<?php echo $pesoCliente ?>" min="0" max="300" required>
                </div>
                <div class="form-group">
                    <label for="peso">Altezza cliente (m)</label>
                    <input type="number" step="0.01" name="altezza" id="altezza" tabindex="1" class="form-control" 
                           placeholder="Altezza (m)" value="<?php echo $altezzaCliente ?>" min="0" max="2.30" required>
                </div>
                <div class="form-group">
                    <button type="submit" class="btn btn-danger">Modifica</button>
                </div>
            </form>
        </div>
    </div>
</div>
