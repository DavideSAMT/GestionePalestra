<div class="wrapper">
    <header>
        <nav>
            <div class="menu-icon">
                <i class="fa fa-bars fa-2x"></i>
            </div>
            <div class="logo">
                GESTIONE PALESTRA
            </div>
            <div class="menu">
                <ul>
                    <li><a href="<?php echo URL ?>responsabileController">Home Responsabile</a></li>
                    <li><a href="<?php echo URL ?>login/logout">Logout</a></li>
                </ul>
            </div>
        </nav>
    </header>
    <div class="content">
        <div class="container">
            <br>
            <form method="POST" action="<?php echo URL?>responsabileController/setPassword/<?php echo $id ?>">
                <div class="form-group">
                    <input type="password" class="form-control" name="newPwd" placeholder="Nuova Password" id="first" required="true" onkeyup="controllaPassword()">
                </div>
                <div class="form-group">
                    <input type="password" class="form-control" name="confPwd" placeholder="Ripeti Password" id="second" onkeyup="controllaPassword()" required="true">
                    <div class="valid-feedback">
                        Le password corrispondono !
                    </div>
                    <div class="invalid-feedback">
                        Le password non corrispondono !
                    </div>
                </div>
                <button type="submit" class="btn btn-danger disabled" id="buttonR">Reimposta</button>
            </form>
        </div>
    </div>
</div>
<script>
    function controllaPassword() {
        var first, second, fv, sv, btn;
        // Riferimento al primo input
        first = document.getElementById('first');
        // Valore del primo input
        fv = first.value;
        // Riferimento al secondo input
        second = document.getElementById('second');
        // Valore del secondo input
        sv = second.value;
        // Riferimento del pulsante
        btn = document.getElementById('buttonR');
        // Controllo che i due valori siano UGUALI
        if (sv === fv) {
            // Rendo valido l'input
            second.setAttribute('class', 'form-control is-valid');
            // Abilito il pulsante
            btn.setAttribute('class', 'btn btn-danger');
        } else {
            // Rendo invalido l'input
            second.setAttribute('class', 'form-control is-invalid');
            // DIsabilito il pulsante
            btn.setAttribute('class', 'btn btn-danger disabled');
        }
    }
</script>